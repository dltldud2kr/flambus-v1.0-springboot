import React, { useState, useEffect, useRef } from 'react';
import styled from 'styled-components'
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import CollapseTab from 'components/CollapseTab';

// export const LoginContainer = styled.div`
//     padding-Top:60px;
// `


function ShopInfo(props) {
    const navigate = useNavigate();
    const location = useLocation();
    const [searchParams, setSearchParams] = useSearchParams();
    //요청한 스토어 idx
    const [storeIdx, setStoreIdx] = useState(searchParams.get("idx"))

    return (
        <div className="contents shop_info_wrap" id="contents">

            <div className="Plogin">
                <div class="storeTopWrap">
                    <div class="sub_menu">
                        <div class="left">
                            <span style={{ fontSize: 12, fontWeight: 600, color: '#B77719' }}>신선했던</span>
                        </div>
                        <div class="right">
                            <span style={{ fontSize: 12, fontWeight: 600, color: '#B77719' }}>나만의 탐험지</span>
                        </div>
                    </div>
                    <div class="title_area">
                        <div class="title_text">
                            <span style={{ coor: '#111', fontWeight: '800', fontSize: 24 }}>긴자료코 경산 하양점</span>
                        </div>
                        <div class="store_info_wrap">
                            <div class="left" style={{ gap: 4 }} onClick={() => alert("준비중")}  >
                                <img src="/assets/images/zzim_icon.png" />
                                <span style={{ fontSize: 14, marginTop: 2 }}>16</span>
                            </div>
                            <div class="right" onClick={() => alert("준비중")} >
                                <span style={{ fontWeight: 'bold', fontSize: 14 }}>탐험일지</span><span style={{ marginLeft: 8, fontSize: 14 }}>32개</span>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="address_wrap" style={{ marginTop: 22, justifyContent: 'center', lineHeight: '22px' }}>
                            <span style={{ minWidth: 60, fontSize: 14, fontWeight: 600 }}>주소</span>
                            <span style={{ fontSize: 14 }}>이름이 긴 경우에는 경북 경산시 하양읍 서사도리9로 25 드립스퀘어 1106호</span>
                        </div>
                        <div class="address_wrap" style={{ lineHeight: '22px' }}>
                            <span style={{ minWidth: 60, fontSize: 14, fontWeight: 600 }}>전화번호</span>
                            <span style={{ fontSize: 14 }}>053-123-4567</span>
                        </div>
                    </div>
                </div>
                <div class="title_area_div" />
                <div class="storeBottomWrap">
                    <div class="container">
                        {/* <span style={{ fontSize: 16,marginBottom:12, fontWeight: '600' }}>다른 탐험가들의 탐험일지에요!</span> */}
                        {/* <div class = "filter_button">
                             <img src="/assets/images/filter.png" />
                            <span style = {{fontSize:14,fontWeight:400}}>필터</span>
                        </div> */}
                        <div class = "collpase_tab_view">
                            <CollapseTab />
                        </div>
                    </div>

                </div>
                
                <div id = 'create_review' className="bottom_button">
                <span>탐험일지 작성하기</span>
                </div>
            </div>

        </div>
    )

}
export default ShopInfo;